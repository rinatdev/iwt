
// function change(){
//     let name = document.getElementById("name");
//     let img = document.getElementById("img");
//     if (name == "Vanezzia", img.src=="https://cdn.pixabay.com/photo/2018/06/06/06/45/venice-3457173_960_720.jpg"
//     ){
//         name.innerHTML = "Paris";
//         img.src  = "https://eturbonews.com/wp-content/uploads/2020/05/0a1-99.jpg";
//         name.style.color = "blue";
//         document.body.style.background = "beige";
// }
// else{
//     name.innerHTML = "Vanezzia";
//     img.src  = "https://cdn.pixabay.com/photo/2018/06/06/06/45/venice-3457173_960_720.jpg";
//     name.style.color = "black";
//     document.body.style.background = "white"; 
// }
// }

// let p = 0;
// function add(){
//     p=p+1;
//     document.getElementById("p").innerHTML=p;
// }

// function sub(){
//     if(p<0){
//         document.getElementById("p").innerHTML=p;
//     }
//     else{
//         p=p-1;
//     document.getElementById("p").innerHTML=p;
//     }
// }

